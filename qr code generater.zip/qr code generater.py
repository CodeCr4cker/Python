#!/usr/bin/env python3
"""
QR Code Generator - Debug Version
Tests URL and creates working QR codes step by step
"""

from PIL import Image, ImageDraw, ImageFont
import qrcode

def test_url(url):
    """Test if URL is valid and formatted correctly"""
    print(f"\n🔍 Testing URL: {url}")
    print(f"   Length: {len(url)} characters")
    
    # Check for common issues
    issues = []
    if len(url) > 200:
        issues.append("⚠️  URL is very long (may cause QR issues)")
    if ' ' in url:
        issues.append("⚠️  URL contains spaces")
    if not url.startswith(('http://', 'https://')):
        issues.append("⚠️  URL missing http:// or https://")
    
    if issues:
        print("\n❌ URL Issues Found:")
        for issue in issues:
            print(f"   {issue}")
        return False
    else:
        print("✅ URL looks good!")
        return True

def generate_basic_qr(url, filename="qr_basic.png"):
    """Generate a basic, guaranteed-to-work QR code"""
    print(f"\n📱 Creating basic QR code: {filename}")
    
    qr = qrcode.QRCode(
        version=1,  # Smallest version that fits the data
        error_correction=qrcode.constants.ERROR_CORRECT_M,  # Medium correction
        box_size=10,
        border=4,
    )
    
    qr.add_data(url)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filename)
    
    print(f"✅ Saved: {filename}")
    print(f"   Version: {qr.version}")
    print(f"   Size: {img.size[0]}x{img.size[1]} pixels")
    return img

def generate_high_quality_qr(url, filename="qr_hq.png"):
    """Generate a high-quality QR code with better error correction"""
    print(f"\n📱 Creating high-quality QR code: {filename}")
    
    qr = qrcode.QRCode(
        version=None,  # Auto-size
        error_correction=qrcode.constants.ERROR_CORRECT_H,  # High correction
        box_size=15,
        border=6,
    )
    
    qr.add_data(url)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filename)
    
    print(f"✅ Saved: {filename}")
    print(f"   Version: {qr.version}")
    print(f"   Size: {img.size[0]}x{img.size[1]} pixels")
    return img

def generate_styled_qr(url, filename="qr_styled.png"):
    """Generate a styled QR code (colored but still scannable)"""
    print(f"\n🎨 Creating styled QR code: {filename}")
    
    # Create QR with high error correction
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=12,
        border=5,
    )
    
    qr.add_data(url)
    qr.make(fit=True)
    
    # Create colored version (gold/black)
    img = qr.make_image(
        fill_color="#B8860B",  # Gold
        back_color="white"
    )
    
    # Add to a nice card
    card_width = 800
    card_height = 1000
    card = Image.new("RGB", (card_width, card_height), "white")
    
    # Resize and center QR
    qr_size = 600
    img_resized = img.resize((qr_size, qr_size), Image.Resampling.NEAREST)
    
    x = (card_width - qr_size) // 2
    y = 180
    card.paste(img_resized, (x, y))
    
    # Add text
    draw = ImageDraw.Draw(card)
    
    try:
        font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 42)
        font_url = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
    except:
        font_title = ImageFont.load_default()
        font_url = ImageFont.load_default()
    
    # Title
    title = "SCAN ME"
    bbox = draw.textbbox((0, 0), title, font=font_title)
    text_w = bbox[2] - bbox[0]
    draw.text(((card_width - text_w) // 2, 80), title, fill="#B8860B", font=font_title)
    
    # URL
    bbox = draw.textbbox((0, 0), url, font=font_url)
    url_w = bbox[2] - bbox[0]
    draw.text(((card_width - url_w) // 2, card_height - 100), url, fill="gray", font=font_url)
    
    # Border
    draw.rectangle([x-10, y-10, x+qr_size+10, y+qr_size+10], outline="#B8860B", width=3)
    
    card.save(filename)
    print(f"✅ Saved: {filename}")
    return card

def main():
    print("=" * 70)
    print("🔧 QR CODE GENERATOR - DEBUG MODE")
    print("=" * 70)
    print("\nThis will create 3 versions of your QR code for testing:")
    print("  1. qr_basic.png - Simple black & white")
    print("  2. qr_hq.png - High quality with error correction")
    print("  3. qr_styled.png - Styled version on a card")
    print()
    
    # Get URL from user
    url = input("Enter your URL: ").strip()
    
    if not url:
        print("\n❌ No URL entered. Exiting.")
        return
    
    # Fix URL if needed
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
        print(f"✅ Added https:// → {url}")
    
    # Remove spaces
    if ' ' in url:
        url = url.replace(' ', '')
        print(f"✅ Removed spaces → {url}")
    
    # Test URL
    if not test_url(url):
        fix = input("\nContinue anyway? (y/n): ").strip().lower()
        if fix != 'y':
            return
    
    print("\n" + "=" * 70)
    print("GENERATING QR CODES...")
    print("=" * 70)
    
    # Generate all three versions
    generate_basic_qr(url)
    generate_high_quality_qr(url)
    generate_styled_qr(url)
    
    print("\n" + "=" * 70)
    print("✅ ALL DONE!")
    print("=" * 70)
    print("\n📱 TESTING STEPS:")
    print("   1. Open your phone's camera or QR scanner")
    print("   2. Scan 'qr_basic.png' first")
    print("   3. If basic works, try 'qr_hq.png'")
    print("   4. If HQ works, try 'qr_styled.png'")
    print()
    print("   Tell me which ones work and which don't!")
    print("=" * 70)

if __name__ == "__main__":
    main()