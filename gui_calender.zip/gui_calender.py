# Importing tkinter module
from tkinter import *
# Importing calendar module
import calendar

# Function to show calendar of the given year
def showCalendar():
    gui = Tk()
    gui.config(background='grey')
    gui.title("Calendar for the Year")
    gui.geometry("520x550+420+150")
    gui.resizable(False, False)

    # Get the year from the Entry widget
    year = int(year_field.get())

    # Get the calendar content for the specified year
    gui_content = calendar.calendar(year)
    calYear = Label(gui, text=gui_content, font="Consolas 10 bold")
    calYear.grid(row=5, column=1, padx=5)
    
    gui.mainloop()

# Driver code
if __name__ == "__main__":
    # Create a basic GUI window
    root = Tk()
    root.config(background='grey')
    root.title("Calendar Application")
    root.geometry("300x100+600+250")
    root.resizable(False, False)

    # Label for the year input
    year_label = Label(root, text="Enter Year", font=("Calibri", 12))
    year_label.grid(row=1, column=0, padx= 30, pady= 15)

    # Entry field for the year input
    year_field = Entry(root)
    year_field.grid(row=1, column=1)

    # Button to display the calendar
    show_button = Button(root, text="Show Calendar", cursor= 'hand2', command=showCalendar)
    show_button.grid(row=2, column=1)

    # Run the main loop
    root.mainloop()