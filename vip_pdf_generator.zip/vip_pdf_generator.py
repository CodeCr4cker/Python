"""
╔══════════════════════════════════════════════════════════════════╗
║       VIP PDF GENERATOR — GUI Edition with Watermark Support     ║
║  Full Tkinter interface · Text/Image watermarks · Theme chooser  ║
╚══════════════════════════════════════════════════════════════════╝

Requirements:
    pip install reportlab pillow

Run:
    python vip_pdf_generator_gui.py
"""

# ── Imports ───────────────────────────────────────────────────────────────────
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
import threading
import os
import math
import tempfile

from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer,
    ListFlowable, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame

from PIL import Image as PILImage


# ═══════════════════════════════════════════════════════════════════════════════
#  DESIGN THEMES
# ═══════════════════════════════════════════════════════════════════════════════

THEMES = {
    "VIP Gold (Classic)": {
        "bg":         "#FFFDF5",
        "accent":     "#C9A84C",
        "accent2":    "#8B6914",
        "header_bg":  "#1C1C1C",
        "footer_bg":  "#1C1C1C",
        "light":      "#F5E6B8",
        "code_bg":    "#2B2B2B",
        "title_font": "Helvetica-Bold",
        "body_font":  "Helvetica",
    },
    "Midnight Blue": {
        "bg":         "#F0F4FF",
        "accent":     "#3B5BDB",
        "accent2":    "#1A3099",
        "header_bg":  "#0D1B4B",
        "footer_bg":  "#0D1B4B",
        "light":      "#BFD0FF",
        "code_bg":    "#1A1F3C",
        "title_font": "Helvetica-Bold",
        "body_font":  "Helvetica",
    },
    "Emerald Executive": {
        "bg":         "#F0FFF4",
        "accent":     "#2E7D32",
        "accent2":    "#1B5E20",
        "header_bg":  "#1B5E20",
        "footer_bg":  "#1B5E20",
        "light":      "#A5D6A7",
        "code_bg":    "#1B2E1B",
        "title_font": "Helvetica-Bold",
        "body_font":  "Helvetica",
    },
    "Royal Crimson": {
        "bg":         "#FFF8F8",
        "accent":     "#C62828",
        "accent2":    "#7B0000",
        "header_bg":  "#3E0000",
        "footer_bg":  "#3E0000",
        "light":      "#FFCDD2",
        "code_bg":    "#2E0000",
        "title_font": "Helvetica-Bold",
        "body_font":  "Helvetica",
    },
    "Monochrome Pro": {
        "bg":         "#FAFAFA",
        "accent":     "#212121",
        "accent2":    "#424242",
        "header_bg":  "#000000",
        "footer_bg":  "#000000",
        "light":      "#BDBDBD",
        "code_bg":    "#1A1A1A",
        "title_font": "Helvetica-Bold",
        "body_font":  "Helvetica",
    },
    "Purple Prestige": {
        "bg":         "#FAF5FF",
        "accent":     "#7B1FA2",
        "accent2":    "#4A0072",
        "header_bg":  "#2A004A",
        "footer_bg":  "#2A004A",
        "light":      "#E1BEE7",
        "code_bg":    "#1A0030",
        "title_font": "Helvetica-Bold",
        "body_font":  "Helvetica",
    },
}


# ═══════════════════════════════════════════════════════════════════════════════
#  PDF ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

def hex_to_rl_color(hex_str):
    return colors.HexColor(hex_str)


def draw_page(c, doc, theme, footer_label,
              wm_type, wm_text, wm_image_path,
              wm_opacity, wm_rotation, wm_position,
              wm_font_size, wm_color):
    """Draws border + watermark on every page."""
    c.saveState()
    w, h = doc.pagesize

    BG      = hex_to_rl_color(theme["bg"])
    ACCENT  = hex_to_rl_color(theme["accent"])
    ACCENT2 = hex_to_rl_color(theme["accent2"])
    HBKG    = hex_to_rl_color(theme["header_bg"])
    LIGHT   = hex_to_rl_color(theme["light"])

    # Background
    c.setFillColor(BG)
    c.rect(0, 0, w, h, fill=1, stroke=0)

    # ── Watermark (drawn BEFORE border so border sits on top) ─────────────────
    if wm_type == "text" and wm_text.strip():
        _draw_text_watermark(c, w, h, wm_text, wm_opacity, wm_rotation,
                             wm_position, wm_font_size, wm_color)
    elif wm_type == "image" and wm_image_path and os.path.isfile(wm_image_path):
        _draw_image_watermark(c, w, h, wm_image_path, wm_opacity,
                              wm_rotation, wm_position)

    # Outer border
    c.setStrokeColor(ACCENT)
    c.setLineWidth(4)
    c.rect(18, 18, w - 36, h - 36)

    # Inner border
    c.setStrokeColor(ACCENT2)
    c.setLineWidth(1)
    c.rect(26, 26, w - 52, h - 52)

    # Corner diamonds
    for cx, cy in [(18, 18), (w-18, 18), (18, h-18), (w-18, h-18)]:
        c.setFillColor(ACCENT)
        p = c.beginPath()
        p.moveTo(cx,   cy + 6)
        p.lineTo(cx+6, cy)
        p.lineTo(cx,   cy - 6)
        p.lineTo(cx-6, cy)
        p.close()
        c.drawPath(p, fill=1, stroke=0)

    # Header band
    c.setFillColor(HBKG)
    c.rect(26, h - 100, w - 52, 74, fill=1, stroke=0)
    c.setFillColor(ACCENT)
    c.rect(26, h - 106, w - 52, 6, fill=1, stroke=0)

    # Footer band
    c.setFillColor(HBKG)
    c.rect(26, 26, w - 52, 40, fill=1, stroke=0)
    c.setFillColor(ACCENT)
    c.rect(26, 66, w - 52, 4, fill=1, stroke=0)

    # Footer text
    c.setFillColor(ACCENT)
    c.setFont("Helvetica-Oblique", 8)
    c.drawCentredString(w / 2, 40, f"✦  {footer_label}  ✦")

    # Page number
    c.setFillColor(LIGHT)
    c.setFont("Helvetica", 8)
    c.drawCentredString(w / 2, 30, f"Page {doc.page}")

    c.restoreState()


def _draw_text_watermark(c, w, h, text, opacity, rotation,
                          position, font_size, color_hex):
    c.saveState()
    c.setFillColor(hex_to_rl_color(color_hex))
    c.setFillAlpha(opacity)

    cx, cy = _get_wm_center(w, h, position)

    c.translate(cx, cy)
    c.rotate(rotation)

    c.setFont("Helvetica-Bold", font_size)
    c.drawCentredString(0, 0, text)
    c.restoreState()


def _draw_image_watermark(c, w, h, img_path, opacity, rotation, position):
    c.saveState()
    c.setFillAlpha(opacity)

    try:
        img = PILImage.open(img_path)
        iw, ih = img.size
        max_dim = min(w, h) * 0.45
        scale = max_dim / max(iw, ih)
        dw, dh = iw * scale, ih * scale

        cx, cy = _get_wm_center(w, h, position)

        c.translate(cx, cy)
        c.rotate(rotation)
        c.drawImage(img_path, -dw/2, -dh/2, width=dw, height=dh,
                    mask='auto', preserveAspectRatio=True)
    except Exception:
        pass
    c.restoreState()


def _get_wm_center(w, h, position):
    positions = {
        "Center":       (w / 2,       h / 2),
        "Top-Left":     (w * 0.25,    h * 0.75),
        "Top-Right":    (w * 0.75,    h * 0.75),
        "Bottom-Left":  (w * 0.25,    h * 0.25),
        "Bottom-Right": (w * 0.75,    h * 0.25),
    }
    return positions.get(position, (w / 2, h / 2))


def build_styles(theme):
    base = getSampleStyleSheet()
    ACCENT  = hex_to_rl_color(theme["accent"])
    ACCENT2 = hex_to_rl_color(theme["accent2"])
    DARK    = colors.HexColor("#1C1C1C")
    LIGHT   = hex_to_rl_color(theme["light"])
    CODE_BG = hex_to_rl_color(theme["code_bg"])

    return {
        "title": ParagraphStyle(
            'VIPTitle', parent=base['Title'],
            fontName=theme["title_font"], fontSize=20,
            textColor=ACCENT, alignment=1,
            spaceAfter=4, spaceBefore=0, leading=26,
        ),
        "subtitle": ParagraphStyle(
            'VIPSubtitle', parent=base['Normal'],
            fontName='Helvetica-Oblique', fontSize=10,
            textColor=LIGHT, alignment=1, spaceAfter=0,
        ),
        "heading": ParagraphStyle(
            'SectionHeading', parent=base['Heading2'],
            fontName='Helvetica-Bold', fontSize=12,
            textColor=ACCENT2, spaceBefore=16, spaceAfter=6, leading=16,
        ),
        "body": ParagraphStyle(
            'VIPBody', parent=base['Normal'],
            fontName=theme["body_font"], fontSize=10,
            textColor=DARK, spaceAfter=6, leading=15,
        ),
        "tip": ParagraphStyle(
            'VIPTip', parent=base['Normal'],
            fontName='Helvetica-Oblique', fontSize=9,
            textColor=ACCENT2, spaceAfter=4, leading=13, leftIndent=10,
        ),
        "code": ParagraphStyle(
            'VIPCode', parent=base['Normal'],
            fontName='Courier', fontSize=9,
            textColor=LIGHT, backColor=CODE_BG,
            spaceAfter=6, leading=13, leftIndent=10, rightIndent=10,
            borderPadding=(6, 8, 6, 8),
        ),
    }


def generate_vip_pdf(cfg):
    """Main PDF builder. cfg is a dict with all settings."""
    theme      = THEMES[cfg["theme"]]
    pagesize   = letter if cfg["pagesize"] == "Letter" else A4
    output     = cfg["output_path"]
    title      = cfg["title"]
    subtitle   = cfg["subtitle"]
    footer     = cfg["footer_label"]
    sections   = cfg["sections"]

    wm_type    = cfg["wm_type"]
    wm_text    = cfg["wm_text"]
    wm_image   = cfg["wm_image"]
    wm_opacity = cfg["wm_opacity"]
    wm_rot     = cfg["wm_rotation"]
    wm_pos     = cfg["wm_position"]
    wm_size    = cfg["wm_font_size"]
    wm_color   = cfg["wm_color"]

    def on_page(c, doc):
        draw_page(c, doc, theme, footer,
                  wm_type, wm_text, wm_image,
                  wm_opacity, wm_rot, wm_pos, wm_size, wm_color)

    doc = SimpleDocTemplate(
        output, pagesize=pagesize,
        leftMargin=0.85*inch, rightMargin=0.85*inch,
        topMargin=1.55*inch,  bottomMargin=1.1*inch,
    )

    ACCENT = hex_to_rl_color(theme["accent"])
    S = build_styles(theme)
    elements = []

    elements.append(Paragraph(title, S["title"]))
    elements.append(Paragraph(subtitle, S["subtitle"]))
    elements.append(Spacer(1, 14))
    elements.append(HRFlowable(width="100%", thickness=1.5,
                                color=ACCENT, spaceAfter=10))

    for section in sections:
        heading  = section.get("heading", "")
        sec_type = section.get("type", "text")
        content  = section.get("content", [])

        if heading:
            elements.append(Paragraph(heading, S["heading"]))

        if sec_type == "steps":
            items = [Paragraph(item, S["body"]) for item in content]
            elements.append(ListFlowable(items, bulletType='1',
                                         leftIndent=20, bulletFontSize=10,
                                         bulletColor=ACCENT))
        elif sec_type == "tips":
            for item in content:
                elements.append(Paragraph(f"✦  {item}", S["tip"]))
        elif sec_type == "code":
            for line in content:
                elements.append(Paragraph(line, S["code"]))
        else:
            for item in content:
                elements.append(Paragraph(item, S["body"]))

        elements.append(Spacer(1, 6))

    elements.append(HRFlowable(width="100%", thickness=1.5,
                                color=ACCENT, spaceAfter=0))

    doc.build(elements, onFirstPage=on_page, onLaterPages=on_page)


# ═══════════════════════════════════════════════════════════════════════════════
#  GUI
# ═══════════════════════════════════════════════════════════════════════════════

class VIPApp(tk.Tk):
    # ── Palette ────────────────────────────────────────────────────────────────
    BG       = "#0F0F13"
    PANEL    = "#1A1A22"
    CARD     = "#22222E"
    BORDER   = "#2E2E3E"
    GOLD     = "#C9A84C"
    GOLD2    = "#F0C96A"
    CREAM    = "#E8DFC8"
    MUTED    = "#888899"
    WHITE    = "#F0EEF8"
    RED      = "#FF4C4C"
    GREEN    = "#4CAF78"

    FONT_H   = ("Georgia", 13, "bold")
    FONT_LBL = ("Segoe UI", 9)
    FONT_SM  = ("Segoe UI", 8)
    FONT_BIG = ("Georgia", 22, "bold")

    def __init__(self):
        super().__init__()
        self.title("PDF Generator")
        self.configure(bg=self.BG)
        self.resizable(True, True)
        self.minsize(900, 680)

        # State
        self.wm_type_var   = tk.StringVar(value="none")
        self.wm_text_var   = tk.StringVar(value="CONFIDENTIAL")
        self.wm_image_var  = tk.StringVar(value="")
        self.wm_opacity    = tk.DoubleVar(value=0.15)
        self.wm_rotation   = tk.DoubleVar(value=35)
        self.wm_position   = tk.StringVar(value="Center")
        self.wm_font_size  = tk.IntVar(value=60)
        self.wm_color_hex  = "#C9A84C"
        self.theme_var     = tk.StringVar(value="VIP Gold (Classic)")
        self.pagesize_var  = tk.StringVar(value="Letter")
        self.output_var    = tk.StringVar(value="My_VIP_Guide.pdf")

        # Section rows
        self.section_frames = []

        self._build_ui()
        self._load_default_content()

    # ─────────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        # ── Title bar ─────────────────────────────────────────────────────────
        top = tk.Frame(self, bg=self.BG, pady=16)
        top.pack(fill="x", padx=24)
        tk.Label(top, text="✦  PDF GENERATOR  ✦",
                 font=self.FONT_BIG, bg=self.BG, fg=self.GOLD).pack()
        tk.Label(top, text="Design your document · Add watermarks · Export PDF",
                 font=self.FONT_SM, bg=self.BG, fg=self.MUTED).pack()

        # Thin gold separator
        tk.Frame(self, bg=self.GOLD, height=1).pack(fill="x", padx=24)

        # ── Main paned area ───────────────────────────────────────────────────
        pane = tk.PanedWindow(self, orient="horizontal",
                              bg=self.BG, sashwidth=4, sashrelief="flat")
        pane.pack(fill="both", expand=True, padx=12, pady=10)

        # Left column
        left = tk.Frame(pane, bg=self.BG)
        pane.add(left, minsize=340)

        # Right column
        right = tk.Frame(pane, bg=self.BG)
        pane.add(right, minsize=420)

        self._build_left(left)
        self._build_right(right)

        # ── Bottom bar ────────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=self.PANEL, pady=8)
        bar.pack(fill="x", side="bottom")

        # Output path row
        prow = tk.Frame(bar, bg=self.PANEL)
        prow.pack(fill="x", padx=20, pady=(0,6))
        tk.Label(prow, text="Output file:", font=self.FONT_LBL,
                 bg=self.PANEL, fg=self.MUTED, width=10, anchor="e").pack(side="left")
        tk.Entry(prow, textvariable=self.output_var, font=self.FONT_LBL,
                 bg=self.CARD, fg=self.WHITE, insertbackground=self.GOLD,
                 relief="flat", bd=0).pack(side="left", fill="x",
                                           expand=True, padx=(6,4), ipady=4)
        tk.Button(prow, text="Browse", font=self.FONT_SM,
                  bg=self.BORDER, fg=self.CREAM, relief="flat", bd=0,
                  padx=8, command=self._browse_output).pack(side="left")

        # Generate + Preview buttons
        btn_row = tk.Frame(bar, bg=self.PANEL)
        btn_row.pack(pady=(0, 4))

        prev_btn = tk.Button(btn_row, text="🔍  PREVIEW",
                             font=("Georgia", 11, "bold"),
                             bg=self.BORDER, fg=self.GOLD,
                             relief="flat", bd=0, padx=20, pady=8,
                             activebackground=self.CARD,
                             cursor="hand2",
                             command=self._preview)
        prev_btn.pack(side="left", padx=(0, 8))

        gen_btn = tk.Button(btn_row, text="⬛  GENERATE PDF",
                            font=("Georgia", 11, "bold"),
                            bg=self.GOLD, fg="#000000",
                            relief="flat", bd=0, padx=20, pady=8,
                            activebackground=self.GOLD2,
                            cursor="hand2",
                            command=self._generate)
        gen_btn.pack(side="left")

        self.status_lbl = tk.Label(bar, text="Ready", font=self.FONT_SM,
                                   bg=self.PANEL, fg=self.MUTED)
        self.status_lbl.pack()

    # ── Left column: Design + Watermark ──────────────────────────────────────
    def _build_left(self, parent):
        canvas = tk.Canvas(parent, bg=self.BG, highlightthickness=0)
        scroll = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        frame  = tk.Frame(canvas, bg=self.BG)
        frame.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))

        # ── DESIGN SETTINGS ──────────────────────────────────────────────────
        self._card_title(frame, "🎨  DESIGN SETTINGS")

        card = self._card(frame)
        self._row(card, "Theme:",
                  ttk.Combobox(card, textvariable=self.theme_var,
                               values=list(THEMES.keys()), state="readonly",
                               width=24))
        self._row(card, "Page Size:",
                  ttk.Combobox(card, textvariable=self.pagesize_var,
                               values=["Letter", "A4"], state="readonly",
                               width=24))

        # ── WATERMARK ────────────────────────────────────────────────────────
        self._card_title(frame, "💧  WATERMARK")
        wcard = self._card(frame)

        # Type radio buttons
        type_f = tk.Frame(wcard, bg=self.CARD)
        type_f.pack(fill="x", pady=(0, 8))
        tk.Label(type_f, text="Type:", font=self.FONT_LBL,
                 bg=self.CARD, fg=self.MUTED, width=10, anchor="e").pack(side="left")
        for val, lbl in [("none","None"), ("text","Text"), ("image","Image")]:
            tk.Radiobutton(type_f, text=lbl, variable=self.wm_type_var,
                           value=val, font=self.FONT_LBL,
                           bg=self.CARD, fg=self.CREAM,
                           selectcolor=self.PANEL, activebackground=self.CARD,
                           command=self._toggle_wm).pack(side="left", padx=6)

        # Text options
        self.wm_text_frame = tk.Frame(wcard, bg=self.CARD)
        self._row(self.wm_text_frame, "Text:",
                  tk.Entry(self.wm_text_frame, textvariable=self.wm_text_var,
                           font=self.FONT_LBL, bg=self.BORDER, fg=self.WHITE,
                           insertbackground=self.GOLD, relief="flat", bd=0,
                           width=22))
        self._slider_row(self.wm_text_frame, "Font size:", self.wm_font_size,
                         20, 120, True)
        # Color
        cf = tk.Frame(self.wm_text_frame, bg=self.CARD)
        cf.pack(fill="x", pady=3)
        tk.Label(cf, text="Color:", font=self.FONT_LBL,
                 bg=self.CARD, fg=self.MUTED, width=10, anchor="e").pack(side="left")
        self.color_btn = tk.Button(cf, text="   ",
                                   bg=self.wm_color_hex, relief="flat",
                                   bd=1, width=3, cursor="hand2",
                                   command=self._pick_color)
        self.color_btn.pack(side="left", padx=6)
        self.color_label = tk.Label(cf, text=self.wm_color_hex,
                                    font=self.FONT_SM, bg=self.CARD, fg=self.MUTED)
        self.color_label.pack(side="left")

        # Image options
        self.wm_img_frame = tk.Frame(wcard, bg=self.CARD)
        img_row = tk.Frame(self.wm_img_frame, bg=self.CARD)
        img_row.pack(fill="x", pady=3)
        tk.Label(img_row, text="Image:", font=self.FONT_LBL,
                 bg=self.CARD, fg=self.MUTED, width=10, anchor="e").pack(side="left")
        tk.Entry(img_row, textvariable=self.wm_image_var, font=self.FONT_SM,
                 bg=self.BORDER, fg=self.WHITE, insertbackground=self.GOLD,
                 relief="flat", bd=0, width=16).pack(side="left", padx=(6,4))
        tk.Button(img_row, text="Browse", font=self.FONT_SM,
                  bg=self.BORDER, fg=self.CREAM, relief="flat", bd=0,
                  padx=6, command=self._browse_image).pack(side="left")

        # Shared watermark options
        self.wm_shared_frame = tk.Frame(wcard, bg=self.CARD)
        self._slider_row(self.wm_shared_frame, "Opacity:",  self.wm_opacity,  0.0, 1.0)
        self._slider_row(self.wm_shared_frame, "Rotation:", self.wm_rotation, -90, 90, True)
        self._row(self.wm_shared_frame, "Position:",
                  ttk.Combobox(self.wm_shared_frame, textvariable=self.wm_position,
                               values=["Center","Top-Left","Top-Right",
                                       "Bottom-Left","Bottom-Right"],
                               state="readonly", width=22))

        self._toggle_wm()   # initial visibility

    # ── Right column: Content ─────────────────────────────────────────────────
    def _build_right(self, parent):
        self._card_title(parent, "📄  DOCUMENT CONTENT")
        card = self._card(parent)

        self.title_entry = tk.Entry(card, font=("Georgia", 10, "bold"),
                                    bg=self.BORDER, fg=self.GOLD,
                                    insertbackground=self.GOLD, relief="flat", bd=0,
                                    width=38)
        self._row(card, "Title:", self.title_entry)

        self.subtitle_entry = tk.Entry(card, font=self.FONT_LBL,
                                       bg=self.BORDER, fg=self.CREAM,
                                       insertbackground=self.GOLD, relief="flat", bd=0,
                                       width=38)
        self._row(card, "Subtitle:", self.subtitle_entry)

        self.footer_entry = tk.Entry(card, font=self.FONT_LBL,
                                     bg=self.BORDER, fg=self.CREAM,
                                     insertbackground=self.GOLD, relief="flat", bd=0,
                                     width=38)
        self._row(card, "Footer:", self.footer_entry)

        # Sections
        self._card_title(parent, "📝  SECTIONS")

        # Scroll frame for sections
        outer = tk.Frame(parent, bg=self.BG)
        outer.pack(fill="both", expand=True, padx=4)

        self.sec_canvas = tk.Canvas(outer, bg=self.BG, highlightthickness=0)
        sec_scroll = tk.Scrollbar(outer, orient="vertical",
                                  command=self.sec_canvas.yview)
        self.sec_frame = tk.Frame(self.sec_canvas, bg=self.BG)
        self.sec_frame.bind("<Configure>",
                            lambda e: self.sec_canvas.configure(
                                scrollregion=self.sec_canvas.bbox("all")))
        self.sec_canvas.create_window((0, 0), window=self.sec_frame, anchor="nw")
        self.sec_canvas.configure(yscrollcommand=sec_scroll.set)
        sec_scroll.pack(side="right", fill="y")
        self.sec_canvas.pack(side="left", fill="both", expand=True)

        # Add section button
        add_btn = tk.Button(parent, text="＋  Add Section",
                            font=self.FONT_LBL,
                            bg=self.PANEL, fg=self.GOLD,
                            relief="flat", bd=0, padx=8, pady=4,
                            cursor="hand2",
                            command=self._add_section)
        add_btn.pack(pady=6)

    # ── Section widget ────────────────────────────────────────────────────────
    def _add_section(self, heading="", sec_type="text", content=""):
        idx = len(self.section_frames)
        card = tk.Frame(self.sec_frame, bg=self.CARD,
                        highlightbackground=self.BORDER,
                        highlightthickness=1)
        card.pack(fill="x", pady=4, padx=4)

        # Header row
        hr = tk.Frame(card, bg=self.CARD)
        hr.pack(fill="x", padx=8, pady=(6,2))
        tk.Label(hr, text=f"§ Section {idx+1}", font=("Segoe UI", 9, "bold"),
                 bg=self.CARD, fg=self.GOLD).pack(side="left")

        type_var = tk.StringVar(value=sec_type)
        for val, lbl in [("text","Text"),("steps","Steps"),
                          ("tips","Tips"),("code","Code")]:
            tk.Radiobutton(hr, text=lbl, variable=type_var, value=val,
                           font=("Segoe UI", 8), bg=self.CARD, fg=self.MUTED,
                           selectcolor=self.PANEL,
                           activebackground=self.CARD).pack(side="left", padx=4)

        # Remove button
        tk.Button(hr, text="✕", font=("Segoe UI", 8),
                  bg=self.CARD, fg=self.RED, relief="flat", bd=0,
                  cursor="hand2",
                  command=lambda c=card, d=None: self._remove_section(card)).pack(side="right")

        # Heading entry
        hrow = tk.Frame(card, bg=self.CARD)
        hrow.pack(fill="x", padx=8, pady=2)
        tk.Label(hrow, text="Heading:", font=self.FONT_SM,
                 bg=self.CARD, fg=self.MUTED, width=8, anchor="e").pack(side="left")
        head_e = tk.Entry(hrow, font=self.FONT_LBL,
                          bg=self.BORDER, fg=self.CREAM,
                          insertbackground=self.GOLD, relief="flat", bd=0)
        head_e.insert(0, heading)
        head_e.pack(side="left", fill="x", expand=True, padx=(6,0), ipady=3)

        # Content text
        tk.Label(card, text="Content (one item per line):",
                 font=self.FONT_SM, bg=self.CARD, fg=self.MUTED,
                 anchor="w").pack(fill="x", padx=8, pady=(4,0))
        text_w = tk.Text(card, height=5, font=("Consolas", 9),
                         bg=self.BORDER, fg=self.WHITE,
                         insertbackground=self.GOLD,
                         relief="flat", bd=0, wrap="word")
        text_w.insert("1.0", content)
        text_w.pack(fill="x", expand=False, padx=8, pady=(2,8))

        self.section_frames.append({
            "card": card, "heading": head_e,
            "type": type_var, "text": text_w
        })

    def _remove_section(self, card):
        self.section_frames = [s for s in self.section_frames
                                if s["card"] is not card]
        card.destroy()

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _card_title(self, parent, text):
        f = tk.Frame(parent, bg=self.BG)
        f.pack(fill="x", padx=6, pady=(12, 4))
        tk.Label(f, text=text, font=self.FONT_H,
                 bg=self.BG, fg=self.GOLD).pack(side="left")
        tk.Frame(f, bg=self.BORDER, height=1).pack(side="left",
                                                    fill="x", expand=True, padx=8)

    def _card(self, parent):
        c = tk.Frame(parent, bg=self.CARD,
                     highlightbackground=self.BORDER, highlightthickness=1)
        c.pack(fill="x", padx=6, pady=2, ipady=6)
        return c

    def _row(self, parent, label, widget):
        f = tk.Frame(parent, bg=parent["bg"])
        f.pack(fill="x", pady=3, padx=8)
        tk.Label(f, text=label, font=self.FONT_LBL,
                 bg=parent["bg"], fg=self.MUTED, width=10, anchor="e").pack(side="left")
        widget.pack(side="left", fill="x", expand=True, padx=(6,0), ipady=4)
        return widget

    def _slider_row(self, parent, label, var, lo, hi, integer=False):
        f = tk.Frame(parent, bg=parent["bg"])
        f.pack(fill="x", pady=3, padx=8)
        tk.Label(f, text=label, font=self.FONT_LBL,
                 bg=parent["bg"], fg=self.MUTED, width=10, anchor="e").pack(side="left")
        val_lbl = tk.Label(f, text=str(var.get()), font=self.FONT_SM,
                           bg=parent["bg"], fg=self.GOLD, width=5)
        val_lbl.pack(side="right")
        def on_change(v, lbl=val_lbl, iv=integer):
            lbl.config(text=str(int(float(v))) if iv else f"{float(v):.2f}")
        sl = ttk.Scale(f, orient="horizontal", from_=lo, to=hi,
                       variable=var, command=on_change)
        sl.pack(side="left", fill="x", expand=True, padx=(6,4))

    def _toggle_wm(self):
        wt = self.wm_type_var.get()
        self.wm_text_frame.pack_forget()
        self.wm_img_frame.pack_forget()
        self.wm_shared_frame.pack_forget()
        if wt == "text":
            self.wm_text_frame.pack(fill="x")
            self.wm_shared_frame.pack(fill="x")
        elif wt == "image":
            self.wm_img_frame.pack(fill="x")
            self.wm_shared_frame.pack(fill="x")

    def _pick_color(self):
        col = colorchooser.askcolor(color=self.wm_color_hex,
                                    title="Watermark Color")
        if col and col[1]:
            self.wm_color_hex = col[1]
            self.color_btn.configure(bg=col[1])
            self.color_label.configure(text=col[1])

    def _browse_image(self):
        p = filedialog.askopenfilename(
            title="Select watermark image",
            filetypes=[("Images","*.png *.jpg *.jpeg *.bmp *.gif"),
                       ("All","*.*")])
        if p:
            self.wm_image_var.set(p)

    def _browse_output(self):
        p = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF","*.pdf")],
            title="Save PDF as")
        if p:
            self.output_var.set(p)

    def _set_status(self, msg, color=None):
        self.status_lbl.configure(text=msg,
                                  fg=color or self.MUTED)
        self.update_idletasks()

    # ── Generate ──────────────────────────────────────────────────────────────
    def _generate(self):
        sections = []
        for sf in self.section_frames:
            raw = sf["text"].get("1.0", "end").strip()
            lines = [l for l in raw.split("\n") if l.strip()]
            sections.append({
                "heading": sf["heading"].get().strip(),
                "type":    sf["type"].get(),
                "content": lines,
            })

        cfg = {
            "output_path":  self.output_var.get(),
            "title":        self.title_entry.get(),
            "subtitle":     self.subtitle_entry.get(),
            "footer_label": self.footer_entry.get(),
            "theme":        self.theme_var.get(),
            "pagesize":     self.pagesize_var.get(),
            "sections":     sections,
            "wm_type":      self.wm_type_var.get(),
            "wm_text":      self.wm_text_var.get(),
            "wm_image":     self.wm_image_var.get(),
            "wm_opacity":   self.wm_opacity.get(),
            "wm_rotation":  self.wm_rotation.get(),
            "wm_position":  self.wm_position.get(),
            "wm_font_size": self.wm_font_size.get(),
            "wm_color":     self.wm_color_hex,
        }

        if not cfg["output_path"]:
            messagebox.showwarning("No output path", "Please set an output file path.")
            return

        self._set_status("⏳  Generating PDF…", self.GOLD)

        def run():
            try:
                generate_vip_pdf(cfg)
                self.after(0, lambda: (
                    self._set_status(f"✅  Saved: {cfg['output_path']}", self.GREEN),
                    messagebox.showinfo("Done",
                                        f"PDF generated successfully!\n\n{cfg['output_path']}")
                ))
            except Exception as ex:
                self.after(0, lambda: (
                    self._set_status(f"❌  Error: {ex}", self.RED),
                    messagebox.showerror("Error", str(ex))
                ))

        threading.Thread(target=run, daemon=True).start()

    # ── Preview ───────────────────────────────────────────────────────────────
    def _preview(self):
        """Render the PDF to a temp file and show a page-thumbnail preview."""
        sections = []
        for sf in self.section_frames:
            raw = sf["text"].get("1.0", "end").strip()
            lines = [l for l in raw.split("\n") if l.strip()]
            sections.append({
                "heading": sf["heading"].get().strip(),
                "type":    sf["type"].get(),
                "content": lines,
            })

        cfg = {
            "output_path":  "",          # filled below with temp path
            "title":        self.title_entry.get(),
            "subtitle":     self.subtitle_entry.get(),
            "footer_label": self.footer_entry.get(),
            "theme":        self.theme_var.get(),
            "pagesize":     self.pagesize_var.get(),
            "sections":     sections,
            "wm_type":      self.wm_type_var.get(),
            "wm_text":      self.wm_text_var.get(),
            "wm_image":     self.wm_image_var.get(),
            "wm_opacity":   self.wm_opacity.get(),
            "wm_rotation":  self.wm_rotation.get(),
            "wm_position":  self.wm_position.get(),
            "wm_font_size": self.wm_font_size.get(),
            "wm_color":     self.wm_color_hex,
        }

        self._set_status("⏳  Rendering preview…", self.GOLD)

        def run():
            try:
                tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
                tmp.close()
                cfg["output_path"] = tmp.name
                generate_vip_pdf(cfg)

                # Try to render pages as images via pdf2image
                try:
                    from pdf2image import convert_from_path
                    images = convert_from_path(tmp.name, dpi=96,
                                               thread_count=2)
                except Exception:
                    images = None

                self.after(0, lambda: (
                    self._set_status("✅  Preview ready", self.GREEN),
                    self._show_preview_window(tmp.name, images)
                ))
            except Exception as ex:
                self.after(0, lambda: (
                    self._set_status(f"❌  Preview error: {ex}", self.RED),
                    messagebox.showerror("Preview Error", str(ex))
                ))

        threading.Thread(target=run, daemon=True).start()

    def _show_preview_window(self, pdf_path, pil_images):
        """Open a Toplevel window showing page thumbnails (or a fallback message)."""
        win = tk.Toplevel(self)
        win.title("PDF Preview")
        win.configure(bg=self.BG)
        win.geometry("860x640")
        win.minsize(600, 480)

        # ── Header ────────────────────────────────────────────────────────────
        hdr = tk.Frame(win, bg=self.PANEL, pady=8)
        hdr.pack(fill="x")
        tk.Label(hdr, text="✦  PDF PREVIEW",
                 font=("Georgia", 13, "bold"),
                 bg=self.PANEL, fg=self.GOLD).pack(side="left", padx=16)

        page_lbl = tk.Label(hdr, text="", font=self.FONT_SM,
                            bg=self.PANEL, fg=self.MUTED)
        page_lbl.pack(side="left", padx=8)

        # Open-in-viewer button
        def open_external():
            import subprocess, sys
            try:
                if sys.platform.startswith("win"):
                    os.startfile(pdf_path)
                elif sys.platform == "darwin":
                    subprocess.call(["open", pdf_path])
                else:
                    subprocess.call(["xdg-open", pdf_path])
            except Exception as e:
                messagebox.showwarning("Open failed",
                                       f"Could not open PDF viewer:\n{e}",
                                       parent=win)

        tk.Button(hdr, text="📂  Open in Viewer",
                  font=self.FONT_SM, bg=self.BORDER, fg=self.CREAM,
                  relief="flat", bd=0, padx=10, pady=4,
                  cursor="hand2", command=open_external).pack(side="right", padx=16)

        # ── Navigation bar ────────────────────────────────────────────────────
        nav = tk.Frame(win, bg=self.PANEL, pady=4)
        nav.pack(fill="x")

        prev_btn = tk.Button(nav, text="◀  Prev",
                             font=self.FONT_SM, bg=self.BORDER, fg=self.CREAM,
                             relief="flat", bd=0, padx=10, pady=3, cursor="hand2")
        prev_btn.pack(side="left", padx=8)

        next_btn = tk.Button(nav, text="Next  ▶",
                             font=self.FONT_SM, bg=self.BORDER, fg=self.CREAM,
                             relief="flat", bd=0, padx=10, pady=3, cursor="hand2")
        next_btn.pack(side="left")

        zoom_var = tk.StringVar(value="Fit")
        zoom_cb = ttk.Combobox(nav, textvariable=zoom_var,
                               values=["Fit", "75%", "100%", "150%", "200%"],
                               state="readonly", width=7)
        zoom_cb.pack(side="right", padx=8)
        tk.Label(nav, text="Zoom:", font=self.FONT_SM,
                 bg=self.PANEL, fg=self.MUTED).pack(side="right")

        tk.Frame(win, bg=self.BORDER, height=1).pack(fill="x")

        # ── Canvas area ───────────────────────────────────────────────────────
        area = tk.Frame(win, bg="#1A1A22")
        area.pack(fill="both", expand=True)

        h_scroll = tk.Scrollbar(area, orient="horizontal")
        h_scroll.pack(side="bottom", fill="x")
        v_scroll = tk.Scrollbar(area, orient="vertical")
        v_scroll.pack(side="right", fill="y")

        canvas = tk.Canvas(area, bg="#1A1A22", highlightthickness=0,
                           xscrollcommand=h_scroll.set,
                           yscrollcommand=v_scroll.set)
        canvas.pack(fill="both", expand=True)
        h_scroll.config(command=canvas.xview)
        v_scroll.config(command=canvas.yview)

        # ── Page rendering logic ──────────────────────────────────────────────
        state = {"page": 0, "photo": None}
        total = len(pil_images) if pil_images else 0

        def render_page(idx):
            canvas.delete("all")
            if not pil_images:
                canvas.create_text(
                    400, 300,
                    text="⚠  Page thumbnails unavailable.\n\nUse 'Open in Viewer' to see the PDF.",
                    font=("Segoe UI", 13), fill=self.MUTED, justify="center"
                )
                page_lbl.config(text="No preview")
                return

            img = pil_images[idx]
            cw = canvas.winfo_width()  or 840
            ch = canvas.winfo_height() or 580

            zoom = zoom_var.get()
            if zoom == "Fit":
                scale = min((cw - 40) / img.width, (ch - 40) / img.height)
            else:
                scale = int(zoom.rstrip("%")) / 100.0

            nw = max(1, int(img.width  * scale))
            nh = max(1, int(img.height * scale))
            resized = img.resize((nw, nh), PILImage.LANCZOS)

            from PIL import ImageTk
            photo = ImageTk.PhotoImage(resized)
            state["photo"] = photo   # keep reference

            x = max(nw // 2 + 20, cw // 2)
            y = max(nh // 2 + 20, ch // 2)
            canvas.config(scrollregion=(0, 0, max(nw + 40, cw), max(nh + 40, ch)))
            cx = max(nw + 40, cw) // 2
            cy = max(nh + 40, ch) // 2

            # Drop shadow
            canvas.create_rectangle(cx - nw//2 + 4, cy - nh//2 + 4,
                                     cx + nw//2 + 4, cy + nh//2 + 4,
                                     fill="#000000", outline="", stipple="gray50")
            canvas.create_image(cx, cy, image=photo)
            page_lbl.config(text=f"Page {idx + 1} of {total}")

        def go_prev():
            if pil_images and state["page"] > 0:
                state["page"] -= 1
                render_page(state["page"])

        def go_next():
            if pil_images and state["page"] < total - 1:
                state["page"] += 1
                render_page(state["page"])

        def on_zoom(*_):
            render_page(state["page"])

        prev_btn.config(command=go_prev)
        next_btn.config(command=go_next)
        zoom_cb.bind("<<ComboboxSelected>>", on_zoom)

        # Keyboard shortcuts
        win.bind("<Left>",  lambda e: go_prev())
        win.bind("<Right>", lambda e: go_next())
        win.bind("<Prior>", lambda e: go_prev())   # Page Up
        win.bind("<Next>",  lambda e: go_next())   # Page Down

        # Mousewheel navigation
        def on_wheel(e):
            if e.delta < 0: go_next()
            else:           go_prev()
        canvas.bind("<MouseWheel>", on_wheel)

        # Render once the window is drawn (so winfo_width is valid)
        win.after(80, lambda: render_page(state["page"]))

        # ── Thumbnail strip (bottom) ──────────────────────────────────────────
        if pil_images and len(pil_images) > 1:
            strip_outer = tk.Frame(win, bg=self.BG, height=80)
            strip_outer.pack(fill="x", side="bottom")
            strip_outer.pack_propagate(False)

            strip_canvas = tk.Canvas(strip_outer, bg=self.BG,
                                     highlightthickness=0, height=80)
            strip_scroll = tk.Scrollbar(strip_outer, orient="horizontal",
                                        command=strip_canvas.xview)
            strip_scroll.pack(side="bottom", fill="x")
            strip_canvas.pack(fill="both", expand=True)
            strip_canvas.config(xscrollcommand=strip_scroll.set)

            strip_frame = tk.Frame(strip_canvas, bg=self.BG)
            strip_canvas.create_window((0, 0), window=strip_frame, anchor="nw")

            thumb_photos = []
            for i, img in enumerate(pil_images):
                th = 60
                tw = int(img.width * (th / img.height))
                thumb = img.resize((tw, th), PILImage.LANCZOS)
                from PIL import ImageTk
                tph = ImageTk.PhotoImage(thumb)
                thumb_photos.append(tph)

                def make_click(idx=i):
                    def click():
                        state["page"] = idx
                        render_page(idx)
                    return click

                btn = tk.Button(strip_frame, image=tph, relief="flat", bd=0,
                                bg=self.BG, cursor="hand2",
                                command=make_click())
                btn.image = tph
                btn.pack(side="left", padx=4, pady=8)

            strip_frame.bind("<Configure>",
                             lambda e: strip_canvas.configure(
                                 scrollregion=strip_canvas.bbox("all")))

    # ── Default content ───────────────────────────────────────────────────────
    def _load_default_content(self):
        self.title_entry.insert(0, "")
        self.subtitle_entry.insert(0, "")
        self.footer_entry.insert(0, "Divyanshu Pandey")

        self._add_section(
            heading="",
            sec_type="text",
            content=(
                " "
                ""
            )
        )
        self._add_section(
            heading="",
            sec_type="steps",
            content=(
                ""
            )
        )
        self._add_section(
            heading="",
            sec_type="code",
            content=(
                ""
            )
        )
        self._add_section(
            heading="",
            sec_type="tips",
            content=(
                ""
            )
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Apply a dark ttk theme if available
    app = VIPApp()
    try:
        style = ttk.Style(app)
        dark_themes = [t for t in style.theme_names()
                       if t in ("clam","alt","default")]
        if dark_themes:
            style.theme_use(dark_themes[0])
        style.configure("TCombobox",
                        fieldbackground="#22222E",
                        background="#22222E",
                        foreground="#F0EEF8",
                        selectbackground="#2E2E3E",
                        selectforeground="#F0EEF8")
        style.configure("Horizontal.TScale",
                        background="#22222E",
                        troughcolor="#2E2E3E",
                        sliderthickness=14)
    except Exception:
        pass
    app.mainloop()
