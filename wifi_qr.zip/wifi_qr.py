import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask
from PIL import Image, ImageDraw, ImageFont
import os

# WiFi credentials
ssid = "¢cYbEr~€X"
password = "Mr.H0ck3r"
security = "WPA"

# WiFi QR string format
wifi_string = f"WIFI:T:{security};S:{ssid};P:{password};;"

# Generate QR code
qr = qrcode.QRCode(
    version=2,
    error_correction=qrcode.constants.ERROR_CORRECT_H,
    box_size=12,
    border=2,
)
qr.add_data(wifi_string)
qr.make(fit=True)

# Styled QR image with rounded modules and custom color
qr_img = qr.make_image(
    image_factory=StyledPilImage,
    module_drawer=RoundedModuleDrawer(),
    color_mask=SolidFillColorMask(
        front_color=(30, 30, 60),
        back_color=(245, 245, 255)
    )
)

qr_img = qr_img.convert("RGBA")
qr_w, qr_h = qr_img.size

# Canvas with padding for labels
pad_top = 60
pad_bottom = 30
pad_side = 40
canvas_w = qr_w + pad_side * 2
canvas_h = qr_h + pad_top + pad_bottom

canvas = Image.new("RGBA", (canvas_w, canvas_h), (245, 245, 255, 255))

# Paste QR onto canvas
canvas.paste(qr_img, (pad_side, pad_top), qr_img)

draw = ImageDraw.Draw(canvas)

# Try to use a decent font, fall back to default
try:
    font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 26)
    font_label = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    font_value = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
except:
    font_title = ImageFont.load_default()
    font_label = font_title
    font_value = font_title

# Title at top
title = "📶 Scan to Connect"
bbox = draw.textbbox((0, 0), title, font=font_title)
tw = bbox[2] - bbox[0]
draw.text(((canvas_w - tw) // 2, 14), title, fill=(30, 30, 60), font=font_title)

# Rounded rectangle border
border_color = (30, 30, 60, 80)
draw.rounded_rectangle([4, 4, canvas_w - 5, canvas_h - 5], radius=18, outline=border_color, width=3)

output_path = os.path.join(os.path.expanduser("~"), "Documents", "wifi_qr.png")
canvas.save(output_path)
print(f"Saved to {output_path}")
print(f"Canvas size: {canvas_w}x{canvas_h}")
