import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os

def convert_image_to_ico(input_image_path, output_image_path, sizes):
    try:
        # Open the image file
        img = Image.open(input_image_path)

        # Save the image in ICO format with the specified sizes
        img.save(output_image_path, format='ICO', sizes=sizes)
    except Exception as e:
        print(f"An error occurred: {e}")

def select_images():
    # Open a file dialog to select multiple image files
    file_paths = filedialog.askopenfilenames(filetypes=[("Image files", "*.png;*.jpeg;*.jpg;*.tiff;*.gif;*.bmp;*.raw")])
    
    if not file_paths:
        return

    # Clear the previous selection
    for widget in frame.winfo_children():
        widget.destroy()

    # Display the selected images in the label box
    for file_path in file_paths:
        img = Image.open(file_path)
        img.thumbnail((100, 100))
        img_tk = ImageTk.PhotoImage(img)
        label = tk.Label(frame, image=img_tk)
        label.image = img_tk  # Keep a reference to avoid garbage collection
        label.pack(side="left", padx=5, pady=5)
    
    # Store the file paths for conversion
    global selected_files
    selected_files = file_paths

def convert_images():
    if not selected_files:
        messagebox.showwarning("No images selected", "Please select images to convert.")
        return

    # Define the sizes for the ICO file
    sizes = [(32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    output_paths = []

    for file_path in selected_files:
        # Define the output path for the ICO file
        output_path = os.path.splitext(file_path)[0] + '.ico'
        convert_image_to_ico(file_path, output_path, sizes)
        output_paths.append(output_path)
    
    # Show a message box with the paths of the converted files
    messagebox.showinfo("Conversion Complete", "Converted files saved at:\n" + "\n".join(output_paths))

# Initialize the main window
root = tk.Tk()
root.title("Image to ICO Converter")

# Create a frame to display selected images
frame = tk.Frame(root, borderwidth=2, relief="sunken")
frame.pack(fill="both", expand=True, padx=10, pady=10)

# Create buttons for selecting and converting images
select_button = tk.Button(root, text="Select Images", command=select_images)
select_button.pack(side="left", padx=10, pady=10)

convert_button = tk.Button(root, text="Convert to ICO", command=convert_images)
convert_button.pack(side="right", padx=10, pady=10)

# Initialize the list to store selected file paths
selected_files = []

# Run the main loop
root.mainloop()
