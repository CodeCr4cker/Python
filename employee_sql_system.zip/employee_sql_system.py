import customtkinter as ctk
from tkinter import messagebox
import sqlite3
from datetime import datetime

class EmployeeEntryForm:
    def __init__(self):
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        self.root = ctk.CTk()
        self.root.title("Employee Management System")
        self.root.geometry("700x600")
        self.root.resizable(False, False)
        
        self.current_employee_id = None
        self.db_name = "employees.db"
        
        self.init_database()
        self.create_widgets()
        
    def init_database(self):
        """Initialize the SQLite database and create tables if they don't exist"""
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    age INTEGER NOT NULL,
                    gender TEXT NOT NULL,
                    salary REAL NOT NULL,
                    position TEXT NOT NULL,
                    country TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
            conn.close()
            print("Database initialized successfully!")
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Failed to initialize database: {str(e)}")
    
    def get_connection(self):
        """Get a database connection"""
        return sqlite3.connect(self.db_name)
        
    def create_widgets(self):
        main_frame = ctk.CTkFrame(self.root, corner_radius=20)
        main_frame.pack(fill="both", expand=True, padx=15, pady=15)
        
        title_label = ctk.CTkLabel(
            main_frame, 
            text="Employee Management System", 
            font=ctk.CTkFont(size=24, weight="bold")
        )
        title_label.pack(pady=15)
        
        form_frame = ctk.CTkFrame(main_frame, corner_radius=15)
        form_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        fields_frame = ctk.CTkFrame(form_frame, fg_color="transparent")
        fields_frame.pack(fill="x", padx=15, pady=15)
        
        left_column = ctk.CTkFrame(fields_frame, fg_color="transparent")
        left_column.pack(side="left", fill="both", expand=True, padx=(0, 10))
        
        right_column = ctk.CTkFrame(fields_frame, fg_color="transparent")
        right_column.pack(side="right", fill="both", expand=True, padx=(10, 0))
        
        ctk.CTkLabel(left_column, text="Name:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        self.name_entry = ctk.CTkEntry(left_column, placeholder_text="Enter name", height=30, width=200)
        self.name_entry.pack(fill="x", pady=(3, 10))
        
        ctk.CTkLabel(left_column, text="Age:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        self.age_entry = ctk.CTkEntry(left_column, placeholder_text="Enter age", height=30, width=200)
        self.age_entry.pack(fill="x", pady=(3, 10))
        
        ctk.CTkLabel(left_column, text="Gender:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        gender_radio_frame = ctk.CTkFrame(left_column, fg_color="transparent")
        gender_radio_frame.pack(fill="x", pady=(3, 10))
        
        self.gender_var = ctk.StringVar(value="Male")
        
        self.male_radio = ctk.CTkRadioButton(gender_radio_frame, text="Male", variable=self.gender_var, value="Male", font=ctk.CTkFont(size=10))
        self.male_radio.pack(side="left", padx=(0, 5))
        
        self.female_radio = ctk.CTkRadioButton(gender_radio_frame, text="Female", variable=self.gender_var, value="Female", font=ctk.CTkFont(size=10))
        self.female_radio.pack(side="left", padx=(0, 5))
        
        self.other_radio = ctk.CTkRadioButton(gender_radio_frame, text="Other", variable=self.gender_var, value="Other", font=ctk.CTkFont(size=10))
        self.other_radio.pack(side="left")
        
        ctk.CTkLabel(right_column, text="Salary:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        self.salary_entry = ctk.CTkEntry(right_column, placeholder_text="Enter salary", height=30, width=200)
        self.salary_entry.pack(fill="x", pady=(3, 10))
        
        ctk.CTkLabel(right_column, text="Position:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        self.position_entry = ctk.CTkEntry(right_column, placeholder_text="Enter position", height=30, width=200)
        self.position_entry.pack(fill="x", pady=(3, 10))
        
        ctk.CTkLabel(right_column, text="Country:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        self.country_combo = ctk.CTkComboBox(
            right_column,
            values=["United States", "United Kingdom", "Canada", "Australia", "India", "Germany", "France"],
            height=30,
            width=200
        )
        self.country_combo.pack(fill="x", pady=(3, 10))
        self.country_combo.set("United States")
        
        button_frame = ctk.CTkFrame(form_frame, fg_color="transparent")
        button_frame.pack(fill="x", padx=15, pady=(0, 15))
        
        self.save_button = ctk.CTkButton(
            button_frame,
            text="Save",
            command=self.save_employee,
            height=35,
            width=100,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color="#2fa572",
            hover_color="#106A43"
        )
        self.save_button.pack(side="left", padx=(0, 8))
        
        self.update_button = ctk.CTkButton(
            button_frame,
            text="Update",
            command=self.update_employee,
            height=35,
            width=100,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color="#ff6b35",
            hover_color="#e55a2b"
        )
        self.update_button.pack(side="left", padx=(0, 8))
        
        self.delete_button = ctk.CTkButton(
            button_frame,
            text="Delete",
            command=self.delete_employee,
            height=35,
            width=100,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color="#d62828",
            hover_color="#b02020"
        )
        self.delete_button.pack(side="left", padx=(0, 8))
        
        self.clear_button = ctk.CTkButton(
            button_frame,
            text="Clear",
            command=self.clear_form,
            height=35,
            width=100,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color="#636363",
            hover_color="#525252"
        )
        self.clear_button.pack(side="left")
        
        list_frame = ctk.CTkFrame(form_frame, fg_color="transparent")
        list_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        ctk.CTkLabel(list_frame, text="Employee List:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w")
        
        self.employee_listbox = ctk.CTkTextbox(list_frame, height=120, font=ctk.CTkFont(size=10))
        self.employee_listbox.pack(fill="both", expand=True, pady=(3, 8))
        
        self.load_button = ctk.CTkButton(
            list_frame,
            text="Load Selected Employee",
            command=self.load_selected_employee,
            height=30,
            font=ctk.CTkFont(size=11, weight="bold")
        )
        self.load_button.pack(fill="x")
        
        self.update_employee_list()
        
    def save_employee(self):
        """Save a new employee to the database"""
        if self.validate_form():
            try:
                conn = self.get_connection()
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO employees (name, age, gender, salary, position, country)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    self.name_entry.get().strip(),
                    int(self.age_entry.get()),
                    self.gender_var.get(),
                    float(self.salary_entry.get()),
                    self.position_entry.get().strip(),
                    self.country_combo.get()
                ))
                
                conn.commit()
                conn.close()
                
                self.update_employee_list()
                self.clear_form()
                messagebox.showinfo("Success", "Employee saved successfully!")
                
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Failed to save employee: {str(e)}")
    
    def update_employee(self):
        """Update an existing employee in the database"""
        if self.current_employee_id is None:
            messagebox.showwarning("Warning", "Please select an employee to update!")
            return
            
        if self.validate_form():
            try:
                conn = self.get_connection()
                cursor = conn.cursor()
                
                cursor.execute('''
                    UPDATE employees 
                    SET name=?, age=?, gender=?, salary=?, position=?, country=?, updated_at=?
                    WHERE id=?
                ''', (
                    self.name_entry.get().strip(),
                    int(self.age_entry.get()),
                    self.gender_var.get(),
                    float(self.salary_entry.get()),
                    self.position_entry.get().strip(),
                    self.country_combo.get(),
                    datetime.now(),
                    self.current_employee_id
                ))
                
                conn.commit()
                conn.close()
                
                self.update_employee_list()
                self.clear_form()
                messagebox.showinfo("Success", "Employee updated successfully!")
                
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Failed to update employee: {str(e)}")
    
    def delete_employee(self):
        """Delete an employee from the database"""
        if self.current_employee_id is None:
            messagebox.showwarning("Warning", "Please select an employee to delete!")
            return
        
        response = messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this employee?")
        
        if response:
            try:
                conn = self.get_connection()
                cursor = conn.cursor()
                
                cursor.execute('DELETE FROM employees WHERE id=?', (self.current_employee_id,))
                
                conn.commit()
                conn.close()
                
                self.update_employee_list()
                self.clear_form()
                messagebox.showinfo("Success", "Employee deleted successfully!")
                
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Failed to delete employee: {str(e)}")
    
    def clear_form(self):
        """Clear all form fields"""
        self.name_entry.delete(0, "end")
        self.age_entry.delete(0, "end")
        self.gender_var.set("Male")
        self.salary_entry.delete(0, "end")
        self.position_entry.delete(0, "end")
        self.country_combo.set("United States")
        self.current_employee_id = None
    
    def validate_form(self):
        """Validate form inputs"""
        if not self.name_entry.get().strip():
            messagebox.showerror("Error", "Please enter a name!")
            return False
        
        try:
            age = int(self.age_entry.get())
            if age <= 0 or age > 150:
                messagebox.showerror("Error", "Please enter a valid age (1-150)!")
                return False
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid age!")
            return False
        
        try:
            salary = float(self.salary_entry.get())
            if salary < 0:
                messagebox.showerror("Error", "Salary cannot be negative!")
                return False
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid salary!")
            return False
        
        if not self.position_entry.get().strip():
            messagebox.showerror("Error", "Please enter a position!")
            return False
        
        return True
    
    def update_employee_list(self):
        """Refresh the employee list from the database"""
        self.employee_listbox.delete("1.0", "end")
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('SELECT * FROM employees ORDER BY id')
            employees = cursor.fetchall()
            
            conn.close()
            
            if not employees:
                self.employee_listbox.insert("1.0", "No employees found.")
                return
            
            for emp in employees:
                employee_info = f"ID: {emp[0]} | {emp[1]} - {emp[5]} - {emp[6]}\n"
                employee_info += f"   Age: {emp[2]}, Gender: {emp[3]}, Salary: ${emp[4]:,.2f}\n\n"
                self.employee_listbox.insert("end", employee_info)
                
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Failed to load employees: {str(e)}")
    
    def load_selected_employee(self):
        """Load the selected employee's data into the form"""
        try:
            cursor_pos = self.employee_listbox.index("insert")
            cursor_line = int(cursor_pos.split('.')[0])
            
            # Get the text content to extract the ID
            line_content = self.employee_listbox.get(f"{cursor_line}.0", f"{cursor_line}.end")
            
            if "ID:" in line_content:
                # Extract the ID from the line
                id_str = line_content.split("ID:")[1].split("|")[0].strip()
                employee_id = int(id_str)
                
                # Fetch the employee from database
                conn = self.get_connection()
                cursor = conn.cursor()
                
                cursor.execute('SELECT * FROM employees WHERE id=?', (employee_id,))
                emp = cursor.fetchone()
                
                conn.close()
                
                if emp:
                    self.current_employee_id = emp[0]
                    
                    self.name_entry.delete(0, "end")
                    self.name_entry.insert(0, emp[1])
                    
                    self.age_entry.delete(0, "end")
                    self.age_entry.insert(0, str(emp[2]))
                    
                    self.gender_var.set(emp[3])
                    
                    self.salary_entry.delete(0, "end")
                    self.salary_entry.insert(0, str(emp[4]))
                    
                    self.position_entry.delete(0, "end")
                    self.position_entry.insert(0, emp[5])
                    
                    self.country_combo.set(emp[6])
                    
                    messagebox.showinfo("Success", f"Loaded employee: {emp[1]}")
                else:
                    messagebox.showwarning("Warning", "Employee not found!")
            else:
                messagebox.showwarning("Warning", "Please click on an employee entry!")
                
        except Exception as e:
            messagebox.showerror("Error", f"Please click on an employee entry to load!\n{str(e)}")
    
    def run(self):
        """Start the application"""
        self.root.mainloop()

if __name__ == "__main__":
    app = EmployeeEntryForm()
    app.run()