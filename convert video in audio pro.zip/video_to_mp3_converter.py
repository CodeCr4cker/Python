"""
╔══════════════════════════════════════════════════════════════════════╗
║           ADVANCED VIDEO TO MP3 CONVERTER - HACKER EDITION          ║
║       Modern Dark GUI with Batch Conversion & FFmpeg Support         ║
╚══════════════════════════════════════════════════════════════════════╝

Requirements:
    pip install moviepy tkinterdnd2

FFmpeg must be installed and added to PATH:
    - Windows: https://ffmpeg.org/download.html
    - macOS:   brew install ffmpeg
    - Linux:   sudo apt install ffmpeg
"""

import os
import sys
import time
import threading
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from datetime import datetime
import math

# ── Optional drag-and-drop support ──────────────────────────────────
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    DND_AVAILABLE = True
except ImportError:
    DND_AVAILABLE = False

# ── Optional MoviePy support (fallback for FFmpeg-only mode) ─────────
try:
    from moviepy.editor import VideoFileClip
    MOVIEPY_AVAILABLE = True
except ImportError:
    MOVIEPY_AVAILABLE = False


# ════════════════════════════════════════════════════════════════════
#  CONSTANTS & COLOUR PALETTE
# ════════════════════════════════════════════════════════════════════

# Supported video formats
SUPPORTED_FORMATS = (
    "*.mp4", "*.mov", "*.avi", "*.mkv", "*.webm", "*.flv",
    "*.wmv", "*.mpeg", "*.mpg", "*.m4v", "*.3gp", "*.ts",
    "*.mts", "*.m2ts", "*.vob", "*.ogv", "*.rm", "*.rmvb",
    "*.asf", "*.divx", "*.f4v", "*.xvid",
)

FILETYPES = [
    ("All Video Files", " ".join(SUPPORTED_FORMATS)),
    ("MP4 Files",       "*.mp4"),
    ("MKV Files",       "*.mkv"),
    ("AVI Files",       "*.avi"),
    ("MOV Files",       "*.mov"),
    ("WebM Files",      "*.webm"),
    ("All Files",       "*.*"),
]

# Colour palette – matrix / cyberpunk green on black
C = {
    "bg":           "#0a0a0a",
    "bg2":          "#0f0f0f",
    "bg3":          "#141414",
    "panel":        "#111111",
    "border":       "#1a2e1a",
    "accent":       "#00ff41",      # Matrix green
    "accent2":      "#00c832",
    "accent_dim":   "#004d14",
    "cyan":         "#00e5ff",
    "red":          "#ff3131",
    "yellow":       "#ffd700",
    "text":         "#c8ffc8",
    "text_dim":     "#4a7a4a",
    "text_bright":  "#ffffff",
    "success":      "#00ff88",
    "error":        "#ff4444",
    "warning":      "#ffaa00",
}

FONT_MONO  = ("Courier New", 10)
FONT_MONO_SM = ("Courier New", 9)
FONT_TITLE = ("Courier New", 18, "bold")
FONT_HEAD  = ("Courier New", 12, "bold")
FONT_BTN   = ("Courier New", 11, "bold")
FONT_SMALL = ("Courier New", 8)


# ════════════════════════════════════════════════════════════════════
#  HELPER – check FFmpeg
# ════════════════════════════════════════════════════════════════════

def ffmpeg_available() -> bool:
    """Return True if ffmpeg is found in PATH."""
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False


def get_file_size(path: str) -> str:
    """Return human-readable file size."""
    size = os.path.getsize(path)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


# ════════════════════════════════════════════════════════════════════
#  CONVERSION ENGINE
# ════════════════════════════════════════════════════════════════════

def convert_with_ffmpeg(
    input_path: str,
    output_path: str,
    bitrate: str,
    progress_cb=None,
    log_cb=None,
) -> bool:
    """
    Convert a video file to MP3 using FFmpeg.
    progress_cb(float 0-100) is called periodically.
    log_cb(str) receives status messages.
    Returns True on success.
    """
    try:
        # Get duration first
        probe = subprocess.run(
            [
                "ffprobe", "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                input_path,
            ],
            capture_output=True,
            text=True,
        )
        duration = float(probe.stdout.strip() or "0")

        cmd = [
            "ffmpeg", "-y",
            "-i", input_path,
            "-vn",                          # no video
            "-acodec", "libmp3lame",
            "-b:a", bitrate,
            "-ar", "44100",                 # sample rate
            "-ac", "2",                     # stereo
            output_path,
        ]

        process = subprocess.Popen(
            cmd,
            stderr=subprocess.PIPE,
            universal_newlines=True,
        )

        for line in process.stderr:
            # Parse time= from FFmpeg stderr for progress
            if "time=" in line and duration > 0 and progress_cb:
                try:
                    t_str = line.split("time=")[1].split(" ")[0]
                    h, m, s = t_str.split(":")
                    elapsed = int(h) * 3600 + int(m) * 60 + float(s)
                    pct = min(100.0, elapsed / duration * 100)
                    progress_cb(pct)
                except Exception:
                    pass
            if log_cb and line.strip():
                log_cb(line.strip())

        process.wait()
        return process.returncode == 0

    except Exception as exc:
        if log_cb:
            log_cb(f"[FFmpeg ERROR] {exc}")
        return False


def convert_with_moviepy(
    input_path: str,
    output_path: str,
    bitrate: str,
    progress_cb=None,
    log_cb=None,
) -> bool:
    """
    Fallback converter using MoviePy.

    Handles the common 'video_fps' KeyError that occurs with:
      - Audio-only WebM / WEBM files (no video stream)
      - Certain MKV / OGV containers MoviePy can't read video from

    Strategy:
      1. Try VideoFileClip first (works for normal video+audio files).
      2. On 'video_fps' KeyError → fall back to AudioFileClip, which
         reads only the audio stream and avoids the video-metadata crash.
      3. If AudioFileClip also fails, report clearly.
    """
    from moviepy.audio.io.AudioFileClip import AudioFileClip

    # ── Attempt 1: normal VideoFileClip path ────────────────────────
    clip = None
    audio = None
    try:
        if log_cb:
            log_cb("[MoviePy] Loading as VideoFileClip…")
        clip = VideoFileClip(input_path)
        audio = clip.audio
        if audio is None:
            raise ValueError("No audio track found in video clip.")

    except KeyError as ke:
        # 'video_fps' KeyError → file is audio-only or has no video stream
        if log_cb:
            log_cb(f"[MoviePy] VideoFileClip failed ({ke}) – retrying as AudioFileClip…")
        if clip is not None:
            try:
                clip.close()
            except Exception:
                pass
        clip = None
        audio = None

    except Exception as exc:
        if log_cb:
            log_cb(f"[MoviePy] VideoFileClip error ({exc}) – retrying as AudioFileClip…")
        if clip is not None:
            try:
                clip.close()
            except Exception:
                pass
        clip = None
        audio = None

    # ── Attempt 2: AudioFileClip (audio-only / WebM fallback) ────────
    audio_clip_used = False
    if audio is None:
        try:
            if log_cb:
                log_cb("[MoviePy] Loading as AudioFileClip…")
            clip = AudioFileClip(input_path)
            audio = clip          # AudioFileClip IS the audio object
            audio_clip_used = True
        except Exception as exc2:
            if log_cb:
                log_cb(f"[MoviePy ERROR] AudioFileClip also failed: {exc2}")
            return False

    # ── Write MP3 ────────────────────────────────────────────────────
    try:
        if progress_cb:
            progress_cb(10)

        if audio_clip_used:
            # AudioFileClip itself has write_audiofile
            audio.write_audiofile(
                output_path,
                bitrate=bitrate,
                verbose=False,
                logger=None,
            )
        else:
            audio.write_audiofile(
                output_path,
                bitrate=bitrate,
                verbose=False,
                logger=None,
            )

        if progress_cb:
            progress_cb(100)
        return True

    except Exception as exc:
        if log_cb:
            log_cb(f"[MoviePy ERROR] Write failed: {exc}")
        return False

    finally:
        try:
            clip.close()
        except Exception:
            pass


# ════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION CLASS
# ════════════════════════════════════════════════════════════════════

class VideoToMP3App:
    """Main application window."""

    def __init__(self):
        # ── root window ────────────────────────────────────────────
        if DND_AVAILABLE:
            self.root = TkinterDnD.Tk()
        else:
            self.root = tk.Tk()

        self.root.title("▓ V2MP3 ▓  |  Video→MP3 Converter  |  Hacker Edition")
        self.root.geometry("900x780")
        self.root.minsize(800, 680)
        self.root.configure(bg=C["bg"])
        self.root.resizable(True, True)

        # State
        self.file_list: list[str] = []
        self.output_dir = tk.StringVar(value="")
        self.quality    = tk.StringVar(value="320k")
        self.is_running = False
        self._anim_after = None   # animation timer reference
        self._blink_state = True

        # Build UI
        self._build_ui()

        # Check backend availability
        self._check_backends()

        # Kick off the scanline animation
        self._animate_scanline()
        self._blink_cursor()

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.mainloop()

    # ── UI CONSTRUCTION ──────────────────────────────────────────────

    def _build_ui(self):
        """Assemble all UI widgets."""
        self._build_title_bar()
        self._build_drop_zone()
        self._build_file_list()
        self._build_controls()
        self._build_progress_section()
        self._build_log_section()
        self._build_status_bar()

    def _build_title_bar(self):
        """Glowing ASCII header."""
        hdr = tk.Frame(self.root, bg=C["bg"], pady=10)
        hdr.pack(fill="x", padx=15, pady=(12, 0))

        banner = (
            "██╗   ██╗██████╗ ███╗   ███╗██████╗ ██████╗ \n"
            "██║   ██║╚════██╗████╗ ████║██╔══██╗╚════██╗\n"
            "██║   ██║ █████╔╝██╔████╔██║██████╔╝ █████╔╝\n"
            "╚██╗ ██╔╝██╔═══╝ ██║╚██╔╝██║██╔═══╝  ╚═══██╗\n"
            " ╚████╔╝ ███████╗██║ ╚═╝ ██║██║     ██████╔╝\n"
            "  ╚═══╝  ╚══════╝╚═╝     ╚═╝╚═╝     ╚═════╝ "
        )
        lbl = tk.Label(
            hdr, text=banner,
            bg=C["bg"], fg=C["accent"],
            font=("Courier New", 7, "bold"),
            justify="center",
        )
        lbl.pack()

        sub = tk.Label(
            hdr,
            text="[ VIDEO → MP3 CONVERTER  ▸  HACKER EDITION  ▸  FFmpeg Powered ]",
            bg=C["bg"], fg=C["text_dim"],
            font=("Courier New", 9),
        )
        sub.pack(pady=(2, 0))

        # Horizontal separator with glow effect
        tk.Frame(self.root, bg=C["accent"], height=1).pack(fill="x", padx=15)
        tk.Frame(self.root, bg=C["accent_dim"], height=1).pack(fill="x", padx=15)

    def _build_drop_zone(self):
        """Drag-and-drop / click-to-browse zone."""
        outer = tk.Frame(self.root, bg=C["bg"], pady=6)
        outer.pack(fill="x", padx=15, pady=(8, 0))

        # Canvas drop zone with dashed border effect
        self.drop_canvas = tk.Canvas(
            outer, bg=C["panel"], height=90,
            highlightthickness=1,
            highlightbackground=C["border"],
        )
        self.drop_canvas.pack(fill="x")

        self._drop_text_id = self.drop_canvas.create_text(
            450, 45,
            text="⇩  DROP VIDEO FILES HERE  or  CLICK TO BROWSE  ⇩",
            fill=C["accent_dim"],
            font=("Courier New", 12, "bold"),
            anchor="center",
        )

        self.drop_canvas.bind("<Button-1>", lambda e: self._browse_files())
        self.drop_canvas.bind("<Enter>", self._dz_enter)
        self.drop_canvas.bind("<Leave>",  self._dz_leave)

        if DND_AVAILABLE:
            self.drop_canvas.drop_target_register(DND_FILES)
            self.drop_canvas.dnd_bind("<<Drop>>", self._on_drop)

    def _dz_enter(self, _event):
        self.drop_canvas.configure(highlightbackground=C["accent"])
        self.drop_canvas.itemconfig(self._drop_text_id, fill=C["accent"])

    def _dz_leave(self, _event):
        self.drop_canvas.configure(highlightbackground=C["border"])
        self.drop_canvas.itemconfig(self._drop_text_id, fill=C["accent_dim"])

    def _build_file_list(self):
        """Scrollable file queue."""
        frame = tk.LabelFrame(
            self.root,
            text=" ▸ FILE QUEUE ",
            bg=C["bg"], fg=C["accent"],
            font=FONT_MONO,
            bd=1, relief="solid",
            highlightbackground=C["border"],
        )
        frame.pack(fill="both", expand=True, padx=15, pady=(8, 0))

        # Treeview
        cols = ("File", "Size", "Status")
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", height=7)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Treeview",
            background=C["bg3"],
            foreground=C["text"],
            rowheight=24,
            fieldbackground=C["bg3"],
            bordercolor=C["border"],
            font=FONT_MONO_SM,
        )
        style.configure(
            "Treeview.Heading",
            background=C["accent_dim"],
            foreground=C["accent"],
            font=("Courier New", 9, "bold"),
            relief="flat",
        )
        style.map("Treeview", background=[("selected", C["accent_dim"])], foreground=[("selected", C["accent"])])

        self.tree.heading("File",   text="FILENAME")
        self.tree.heading("Size",   text="SIZE")
        self.tree.heading("Status", text="STATUS")
        self.tree.column("File",   width=480, anchor="w")
        self.tree.column("Size",   width=90,  anchor="center")
        self.tree.column("Status", width=150, anchor="center")

        sb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # Queue action buttons
        btn_row = tk.Frame(self.root, bg=C["bg"])
        btn_row.pack(fill="x", padx=15, pady=(4, 0))

        self._make_btn(btn_row, "[ + ADD FILES ]",  self._browse_files,  C["accent"]).pack(side="left", padx=(0, 6))
        self._make_btn(btn_row, "[ ✖ REMOVE SEL ]", self._remove_selected, C["red"]).pack(side="left", padx=(0, 6))
        self._make_btn(btn_row, "[ ⟳ CLEAR ALL ]",  self._clear_all,     C["text_dim"]).pack(side="left")

    def _build_controls(self):
        """Output folder, quality, and convert/open buttons."""
        ctrl = tk.Frame(self.root, bg=C["bg"])
        ctrl.pack(fill="x", padx=15, pady=(10, 0))

        # Output folder
        tk.Label(ctrl, text="OUTPUT DIR:", bg=C["bg"], fg=C["accent"], font=FONT_MONO).grid(row=0, column=0, sticky="w", padx=(0, 6))
        self.out_entry = tk.Entry(
            ctrl, textvariable=self.output_dir,
            bg=C["bg3"], fg=C["text"], insertbackground=C["accent"],
            font=FONT_MONO_SM, relief="flat",
            highlightthickness=1, highlightbackground=C["border"],
            highlightcolor=C["accent"], width=42,
        )
        self.out_entry.grid(row=0, column=1, sticky="ew", padx=(0, 6))
        self._make_btn(ctrl, "[ BROWSE ]", self._browse_output, C["cyan"], pady=0).grid(row=0, column=2, padx=(0, 10))

        # Quality
        tk.Label(ctrl, text="BITRATE:", bg=C["bg"], fg=C["accent"], font=FONT_MONO).grid(row=0, column=3, sticky="w", padx=(0, 6))
        q_frame = tk.Frame(ctrl, bg=C["bg"])
        q_frame.grid(row=0, column=4, sticky="w")
        for q in ("128k", "192k", "320k"):
            rb = tk.Radiobutton(
                q_frame, text=q,
                variable=self.quality, value=q,
                bg=C["bg"], fg=C["text"], selectcolor=C["accent_dim"],
                activebackground=C["bg"], activeforeground=C["accent"],
                font=FONT_MONO_SM, cursor="hand2",
                indicatoron=True,
            )
            rb.pack(side="left", padx=4)

        ctrl.columnconfigure(1, weight=1)

        # Action buttons
        action = tk.Frame(self.root, bg=C["bg"])
        action.pack(fill="x", padx=15, pady=(10, 0))

        self.convert_btn = self._make_btn(
            action, "▶  CONVERT ALL  ▶",
            self._start_conversion, C["accent"],
            font=("Courier New", 12, "bold"), pady=8,
        )
        self.convert_btn.pack(side="left", padx=(0, 10), ipadx=20)

        self.open_btn = self._make_btn(
            action, "[ ⊞ OPEN OUTPUT FOLDER ]",
            self._open_output_folder, C["cyan"],
        )
        self.open_btn.pack(side="left", padx=(0, 10))

        self.stop_btn = self._make_btn(
            action, "[ ■ STOP ]",
            self._stop_conversion, C["red"],
        )
        self.stop_btn.pack(side="left")
        self.stop_btn.configure(state="disabled")

    def _build_progress_section(self):
        """Progress bar + file counter."""
        pf = tk.Frame(self.root, bg=C["bg"])
        pf.pack(fill="x", padx=15, pady=(10, 0))

        tk.Label(pf, text="PROGRESS:", bg=C["bg"], fg=C["accent"], font=FONT_MONO).pack(side="left", padx=(0, 8))

        bar_bg = tk.Frame(pf, bg=C["bg3"], height=18, highlightthickness=1, highlightbackground=C["border"])
        bar_bg.pack(side="left", fill="x", expand=True, pady=2)
        bar_bg.pack_propagate(False)

        self.prog_bar = tk.Frame(bar_bg, bg=C["accent"], height=18, width=0)
        self.prog_bar.pack(side="left", fill="y")

        self.prog_label = tk.Label(
            pf, text="  0 / 0 files  |  0%",
            bg=C["bg"], fg=C["text_dim"], font=FONT_MONO_SM,
        )
        self.prog_label.pack(side="left", padx=(8, 0))

        self._bar_frame = bar_bg   # keep reference

    def _build_log_section(self):
        """Scrollable terminal-style log."""
        lf = tk.LabelFrame(
            self.root,
            text=" ▸ TERMINAL LOG ",
            bg=C["bg"], fg=C["accent"],
            font=FONT_MONO, bd=1, relief="solid",
        )
        lf.pack(fill="x", padx=15, pady=(10, 0))

        self.log_text = tk.Text(
            lf, bg=C["bg"], fg=C["text"],
            font=("Courier New", 8),
            height=6, wrap="word",
            relief="flat",
            insertbackground=C["accent"],
            state="disabled",
        )
        sb2 = tk.Scrollbar(lf, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb2.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        sb2.pack(side="right", fill="y")

        # Colour tags
        self.log_text.tag_config("ok",   foreground=C["success"])
        self.log_text.tag_config("err",  foreground=C["error"])
        self.log_text.tag_config("warn", foreground=C["warning"])
        self.log_text.tag_config("info", foreground=C["text_dim"])
        self.log_text.tag_config("sys",  foreground=C["cyan"])

    def _build_status_bar(self):
        """Bottom status bar."""
        bar = tk.Frame(self.root, bg=C["accent_dim"], height=22)
        bar.pack(fill="x", side="bottom")

        self.status_var = tk.StringVar(value="READY")
        self.status_lbl = tk.Label(
            bar, textvariable=self.status_var,
            bg=C["accent_dim"], fg=C["accent"],
            font=("Courier New", 8, "bold"), anchor="w", padx=8,
        )
        self.status_lbl.pack(side="left", fill="y")

        # Backend indicator
        self.backend_lbl = tk.Label(
            bar, text="",
            bg=C["accent_dim"], fg=C["text_dim"],
            font=("Courier New", 8), anchor="e", padx=8,
        )
        self.backend_lbl.pack(side="right", fill="y")

    # ── WIDGET FACTORY ───────────────────────────────────────────────

    def _make_btn(self, parent, text, cmd, color, font=FONT_BTN, pady=4):
        """Create a styled hacker button with hover glow."""
        btn = tk.Button(
            parent, text=text, command=cmd,
            bg=C["bg3"], fg=color,
            activebackground=color, activeforeground=C["bg"],
            font=font, relief="flat", cursor="hand2",
            pady=pady, padx=8,
            highlightthickness=1,
            highlightbackground=color,
            highlightcolor=color,
        )
        btn.bind("<Enter>", lambda e, b=btn, c=color: b.configure(bg=c, fg=C["bg"]))
        btn.bind("<Leave>", lambda e, b=btn, c=color: b.configure(bg=C["bg3"], fg=c))
        return btn

    # ── BACKEND CHECK ────────────────────────────────────────────────

    def _check_backends(self):
        has_ffmpeg   = ffmpeg_available()
        has_moviepy  = MOVIEPY_AVAILABLE
        has_dnd      = DND_AVAILABLE

        if has_ffmpeg:
            backend = "FFmpeg ✓"
            self._log("FFmpeg detected – maximum format compatibility enabled.", "sys")
        elif has_moviepy:
            backend = "MoviePy ✓  (FFmpeg missing – limited formats)"
            self._log("FFmpeg NOT found. Falling back to MoviePy.", "warn")
            self._log("Install FFmpeg for full format support.", "warn")
        else:
            backend = "NO BACKEND ✗"
            self._log("ERROR: Neither FFmpeg nor MoviePy is available!", "err")
            self._log("Install FFmpeg:  https://ffmpeg.org/download.html", "err")
            messagebox.showerror(
                "Missing Dependencies",
                "No conversion backend found!\n\n"
                "Install FFmpeg:  https://ffmpeg.org/download.html\n"
                "Or:  pip install moviepy",
            )

        dnd_msg = "DnD ✓" if has_dnd else "DnD ✗ (pip install tkinterdnd2)"
        self.backend_lbl.configure(
            text=f"  {backend}  |  {dnd_msg}  "
        )
        if not has_dnd:
            self._log("Drag-and-drop unavailable. pip install tkinterdnd2", "info")

    # ── FILE MANAGEMENT ──────────────────────────────────────────────

    def _browse_files(self):
        paths = filedialog.askopenfilenames(title="Select Video Files", filetypes=FILETYPES)
        self._add_files(paths)

    def _browse_output(self):
        d = filedialog.askdirectory(title="Select Output Directory")
        if d:
            self.output_dir.set(d)

    def _on_drop(self, event):
        """Handle drag-and-drop (tkinterdnd2)."""
        raw = event.data
        # tkinterdnd2 wraps paths with spaces in {}
        paths = self.root.tk.splitlist(raw)
        self._add_files(paths)

    def _add_files(self, paths):
        added = 0
        for p in paths:
            p = p.strip()
            if not p:
                continue
            ext = Path(p).suffix.lower()
            allowed = {s.replace("*", "").lower() for s in SUPPORTED_FORMATS}
            if ext not in allowed and ext != "":
                self._log(f"Skipped (unsupported): {Path(p).name}", "warn")
                continue
            if p not in self.file_list:
                self.file_list.append(p)
                size = get_file_size(p) if os.path.isfile(p) else "?"
                self.tree.insert("", "end", iid=p, values=(Path(p).name, size, "⏳ QUEUED"))
                added += 1

        if added:
            self._log(f"{added} file(s) added to queue.", "ok")
            self._set_status(f"{len(self.file_list)} file(s) in queue.")

    def _remove_selected(self):
        for iid in self.tree.selection():
            self.tree.delete(iid)
            if iid in self.file_list:
                self.file_list.remove(iid)
        self._set_status(f"{len(self.file_list)} file(s) in queue.")

    def _clear_all(self):
        self.file_list.clear()
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._reset_progress()
        self._set_status("Queue cleared.")
        self._log("Queue cleared.", "info")

    # ── CONVERSION ───────────────────────────────────────────────────

    def _start_conversion(self):
        if self.is_running:
            return
        if not self.file_list:
            messagebox.showwarning("Empty Queue", "No video files in the queue!")
            return
        if not ffmpeg_available() and not MOVIEPY_AVAILABLE:
            messagebox.showerror("No Backend", "Install FFmpeg or MoviePy first.")
            return

        self.is_running = True
        self._stop_flag = False
        self.convert_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        threading.Thread(target=self._conversion_worker, daemon=True).start()

    def _stop_conversion(self):
        self._stop_flag = True
        self._log("Stop requested – finishing current file…", "warn")
        self._set_status("STOPPING…")

    def _conversion_worker(self):
        total  = len(self.file_list)
        done   = 0
        errors = 0
        bitrate = self.quality.get()

        self._log(f"═══ Starting batch: {total} file(s) @ {bitrate} ═══", "sys")

        for idx, path in enumerate(list(self.file_list)):
            if self._stop_flag:
                self._log("Batch stopped by user.", "warn")
                break

            name = Path(path).name
            self._log(f"[{idx+1}/{total}] Converting: {name}", "info")
            self._set_status(f"Converting {idx+1}/{total}: {name}")
            self.tree.set(path, "Status", "⚙ CONVERTING")

            # Determine output path
            out_dir = self.output_dir.get().strip()
            if out_dir and os.path.isdir(out_dir):
                out_path = os.path.join(out_dir, Path(path).stem + ".mp3")
            else:
                out_path = str(Path(path).with_suffix(".mp3"))

            success = False
            def progress_cb(pct, p=path):
                self._update_progress(pct, idx, total)

            if ffmpeg_available():
                success = convert_with_ffmpeg(path, out_path, bitrate, progress_cb, self._log)
            elif MOVIEPY_AVAILABLE:
                success = convert_with_moviepy(path, out_path, bitrate, progress_cb, self._log)

            if success:
                done += 1
                self.tree.set(path, "Status", "✔ DONE")
                out_size = get_file_size(out_path) if os.path.isfile(out_path) else "?"
                self._log(f"  ✔ Saved: {Path(out_path).name}  ({out_size})", "ok")
            else:
                errors += 1
                self.tree.set(path, "Status", "✖ ERROR")
                self._log(f"  ✖ Failed: {name}", "err")

        # Done
        self._update_progress(100, total, total)
        self._log(
            f"═══ Batch complete: {done} succeeded, {errors} failed ═══", "sys"
        )
        status = f"Done: {done}/{total} converted, {errors} error(s)."
        self._set_status(status)
        self.root.after(0, self._on_conversion_done)

    def _on_conversion_done(self):
        self.is_running = False
        self.convert_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")

    # ── PROGRESS ─────────────────────────────────────────────────────

    def _update_progress(self, file_pct: float, file_idx: int, total: int):
        """Update the progress bar (runs from worker thread via after)."""
        overall = ((file_idx + file_pct / 100) / max(total, 1)) * 100

        def _do():
            bar_w = self._bar_frame.winfo_width()
            fill  = int(bar_w * overall / 100)
            self.prog_bar.configure(width=max(fill, 0))
            self.prog_label.configure(
                text=f"  {min(file_idx+1, total)} / {total} files  |  {overall:.0f}%"
            )
        self.root.after(0, _do)

    def _reset_progress(self):
        self.prog_bar.configure(width=0)
        self.prog_label.configure(text="  0 / 0 files  |  0%")

    # ── LOGGING ──────────────────────────────────────────────────────

    def _log(self, msg: str, tag: str = "info"):
        """Thread-safe log to terminal widget."""
        ts = datetime.now().strftime("%H:%M:%S")

        def _do():
            self.log_text.configure(state="normal")
            self.log_text.insert("end", f"[{ts}] {msg}\n", tag)
            self.log_text.see("end")
            self.log_text.configure(state="disabled")

        self.root.after(0, _do)

    def _set_status(self, msg: str):
        self.root.after(0, lambda: self.status_var.set(msg))

    # ── OUTPUT FOLDER ────────────────────────────────────────────────

    def _open_output_folder(self):
        d = self.output_dir.get().strip()
        if not d or not os.path.isdir(d):
            # Try to infer from first completed file
            if self.file_list:
                d = str(Path(self.file_list[0]).parent)
            else:
                messagebox.showinfo("Open Folder", "No output folder set.")
                return
        if sys.platform == "win32":
            os.startfile(d)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", d])
        else:
            subprocess.Popen(["xdg-open", d])

    # ── ANIMATIONS ───────────────────────────────────────────────────

    def _animate_scanline(self):
        """Subtle scanline flicker on the drop zone."""
        if not self.is_running:
            colours = [C["accent_dim"], "#003010", "#002010"]
            import random
            c = random.choice(colours)
            try:
                self.drop_canvas.itemconfig(self._drop_text_id, fill=c)
            except Exception:
                pass
        self._anim_after = self.root.after(800, self._animate_scanline)

    def _blink_cursor(self):
        """Blink the status bar text."""
        self._blink_state = not self._blink_state
        if not self.is_running:
            colour = C["accent"] if self._blink_state else C["accent2"]
            self.status_lbl.configure(fg=colour)
        self.root.after(600, self._blink_cursor)

    # ── CLEANUP ───────────────────────────────────────────────────────

    def _on_close(self):
        if self.is_running:
            if not messagebox.askyesno("Quit?", "Conversion in progress. Quit anyway?"):
                return
            self._stop_flag = True
        if self._anim_after:
            self.root.after_cancel(self._anim_after)
        self.root.destroy()


# ════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    VideoToMP3App()
