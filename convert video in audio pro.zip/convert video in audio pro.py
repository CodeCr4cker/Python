from moviepy.editor import VideoFileClip
import tkinter as tk
from tkinter import filedialog
import os

def convert_video_to_mp3():
    # Function to handle the conversion process
    try:
        # Open a file dialog to select the video file
        video_path = filedialog.askopenfilename(
            title="Select Video File",
            filetypes=[("Video Files", "*.mp4 *.mov *.avi *.mkv")]
        )

        if not video_path:
            status_label.config(text="No file selected.")
            return

        # Define the output MP3 file path
        mp3_path = os.path.splitext(video_path)[0] + '.mp3'

        # Load the video file
        video = VideoFileClip(video_path)

        # Extract the audio and write it to an MP3 file
        video.audio.write_audiofile(mp3_path)

        status_label.config(text=f"Successfully converted to {mp3_path}")

    except Exception as e:
        status_label.config(text=f"An error occurred: {e}")

# Create the main Tkinter window
root = tk.Tk()
root.title("Video to MP3 Converter")

# Configure the window
root.geometry("400x200")
root.configure(bg='black')

# Create and pack a label to show status
status_label = tk.Label(root, text="", bg='black', fg='white', font=('Helvetica', 12))
status_label.pack(pady=20)

# Create and pack a button to start the conversion process
convert_button = tk.Button(root, text="Convert Video to MP3", command=convert_video_to_mp3, bg='gray', fg='white')
convert_button.pack(pady=10)

# Start the Tkinter event loop
root.mainloop()
